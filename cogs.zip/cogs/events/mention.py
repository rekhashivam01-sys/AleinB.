from utils import getConfig
import discord
from discord.ext import commands
from utils.Tools import get_ignore_data
import aiosqlite


class Mention(commands.Cog):

    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect("db/block.db") as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS user_blacklist (
                    user_id INTEGER PRIMARY KEY,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            await db.execute('''
                CREATE TABLE IF NOT EXISTS guild_blacklist (
                    guild_id INTEGER PRIMARY KEY,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            await db.commit()

    async def is_blacklisted(self, message):
        async with aiosqlite.connect("db/block.db") as db:
            cursor = await db.execute(
                "SELECT 1 FROM guild_blacklist WHERE guild_id = ?",
                (message.guild.id,)
            )
            if await cursor.fetchone():
                return True
            cursor = await db.execute(
                "SELECT 1 FROM user_blacklist WHERE user_id = ?",
                (message.author.id,)
            )
            if await cursor.fetchone():
                return True
        return False

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        if await self.is_blacklisted(message):
            return

        ignore_data = await get_ignore_data(message.guild.id)
        if (
            str(message.author.id) in ignore_data["user"]
            or str(message.channel.id) in ignore_data["channel"]
        ):
            return

        if message.reference and message.reference.resolved:
            if isinstance(message.reference.resolved, discord.Message):
                if message.reference.resolved.author.id == self.bot.user.id:
                    return

        guild_id = message.guild.id
        data = await getConfig(guild_id)
        prefix = data["prefix"]

        if self.bot.user in message.mentions and len(message.content.strip().split()) == 1:
            from discord import ui
            from utils.config import serverLink, invite_link, website_link

            view = ui.LayoutView()
            container = ui.Container(accent_color=None)

            container.add_item(ui.TextDisplay(
                f"**Server prefix** \u2192 `{prefix}`\n"
                f"\u2514 For custom prefix use `.prefix set <prefix>`"
            ))

            class InviteButton(ui.Button):
                def __init__(self_inner):
                    super().__init__(
                        label="Invite",
                        style=discord.ButtonStyle.secondary,
                        url=invite_link,
                    )

            class SupportButton(ui.Button):
                def __init__(self_inner):
                    super().__init__(
                        label="Support Server",
                        style=discord.ButtonStyle.secondary,
                        url=serverLink,
                    )

            container.add_item(ui.ActionRow(InviteButton(), SupportButton()))
            view.add_item(container)
            await message.channel.send(view=view)


async def setup(bot):
    await bot.add_cog(Mention(bot))
