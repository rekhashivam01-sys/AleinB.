from discord.ext import commands
from core import Zyntax as Yuna, Cog
from utils.Tools import getConfig
import discord
import logging
from discord import ui
from utils.config import serverLink, invite_link, website_link

logging.basicConfig(
    level=logging.INFO,
    format="\x1b[38;5;197m[\x1b[0m%(asctime)s\x1b[38;5;197m]\x1b[0m -> \x1b[38;5;197m%(message)s\x1b[0m",
    datefmt="%H:%M:%S",
)

client = Yuna()

LOG_CHANNEL_ID = 1324668336470102141


class Guild(Cog):
    def __init__(self, client: Yuna):
        self.client = client

    # ─── Welcome message sent inside the new server ───────────────────────────

    @commands.Cog.listener(name="on_guild_join")
    async def on_guild_join(self, guild: discord.Guild):
        try:
            # --- Send welcome message in the server ---
            target_channel = None

            # 1. Try the system channel
            if guild.system_channel and guild.system_channel.permissions_for(guild.me).send_messages:
                target_channel = guild.system_channel

            # 2. Fall back to first text channel we can write in
            if target_channel is None:
                for ch in guild.text_channels:
                    if ch.permissions_for(guild.me).send_messages:
                        target_channel = ch
                        break

            if target_channel:
                data = await getConfig(guild.id)
                prefix = data.get("prefix", ".")

                view = ui.LayoutView()
                container = ui.Container(accent_color=None)

                container.add_item(ui.TextDisplay(
                    f"**Thanks for adding !**\n\n"
                    f"- My default prefix is `{prefix}`\n"
                    f"- Use `{prefix}help` or `/help` in the server for commands\n"
                    f"- For questions or details join [Support Server]({serverLink})\n"
                    f"-# By Zyntax Development"
                ))

                class SupportButton(ui.Button):
                    def __init__(self_inner):
                        super().__init__(
                            label="Support Server",
                            style=discord.ButtonStyle.secondary,
                            url=serverLink,
                        )

                class WebsiteButton(ui.Button):
                    def __init__(self_inner):
                        super().__init__(
                            label="Website",
                            style=discord.ButtonStyle.secondary,
                            url=website_link,
                        )

                container.add_item(ui.ActionRow(SupportButton(), WebsiteButton()))
                view.add_item(container)
                await target_channel.send(view=view)

            # --- Log to owner's log channel ---
            rope = [inv for inv in await guild.invites() if inv.max_age == 0 and inv.max_uses == 0]
            me = self.client.get_channel(LOG_CHANNEL_ID)
            if me is None:
                logging.error(f"Log channel {LOG_CHANNEL_ID} not found.")
                return

            channels = len(set(self.client.get_all_channels()))
            embed = discord.Embed(title=f"{guild.name}'s Information", color=0x000000)
            embed.set_author(name="Guild Joined")
            embed.set_footer(text=f"Added in {guild.name}")
            embed.add_field(
                name="About",
                value=(
                    f"Name: {guild.name}\n"
                    f"ID: {guild.id}\n"
                    f"Owner: {guild.owner} ({guild.owner_id})\n"
                    f"Created: {guild.created_at.strftime('%m/%d/%Y')}\n"
                    f"Members: {len(guild.members)}"
                ),
                inline=False,
            )
            embed.add_field(name="Description", value=guild.description or "No description", inline=False)
            embed.add_field(
                name="Members",
                value=(
                    f"Total: {len(guild.members)}\n"
                    f"Humans: {len([m for m in guild.members if not m.bot])}\n"
                    f"Bots: {len([m for m in guild.members if m.bot])}"
                ),
                inline=False,
            )
            embed.add_field(
                name="Channels",
                value=(
                    f"Categories: {len(guild.categories)}\n"
                    f"Text: {len(guild.text_channels)}\n"
                    f"Voice: {len(guild.voice_channels)}\n"
                    f"Threads: {len(guild.threads)}"
                ),
                inline=False,
            )
            embed.add_field(
                name="Bot Stats",
                value=f"Servers: `{len(self.client.guilds)}`\nUsers: `{len(self.client.users)}`\nChannels: `{channels}`",
                inline=False,
            )
            if guild.icon:
                embed.set_thumbnail(url=guild.icon.url)
            embed.timestamp = discord.utils.utcnow()
            await me.send(rope[0] if rope else "No Pre-Made Invite Found", embed=embed)

            if not guild.chunked:
                await guild.chunk()

        except Exception as e:
            logging.error(f"Error in on_guild_join: {e}")

    @commands.Cog.listener(name="on_guild_remove")
    async def on_guild_remove(self, guild: discord.Guild):
        try:
            idk = self.client.get_channel(LOG_CHANNEL_ID)
            if idk is None:
                logging.error(f"Log channel {LOG_CHANNEL_ID} not found.")
                return

            channels = len(set(self.client.get_all_channels()))
            embed = discord.Embed(title=f"{guild.name}'s Information", color=0x000000)
            embed.set_author(name="Guild Removed")
            embed.set_footer(text=guild.name)
            embed.add_field(
                name="About",
                value=(
                    f"Name: {guild.name}\n"
                    f"ID: {guild.id}\n"
                    f"Owner: {guild.owner} ({guild.owner_id})\n"
                    f"Created: {guild.created_at.strftime('%m/%d/%Y')}\n"
                    f"Members: {len(guild.members)}"
                ),
                inline=False,
            )
            embed.add_field(name="Description", value=guild.description or "No description", inline=False)
            embed.add_field(
                name="Members",
                value=(
                    f"Total: {len(guild.members)}\n"
                    f"Humans: {len([m for m in guild.members if not m.bot])}\n"
                    f"Bots: {len([m for m in guild.members if m.bot])}"
                ),
                inline=False,
            )
            embed.add_field(
                name="Channels",
                value=(
                    f"Categories: {len(guild.categories)}\n"
                    f"Text: {len(guild.text_channels)}\n"
                    f"Voice: {len(guild.voice_channels)}\n"
                    f"Threads: {len(guild.threads)}"
                ),
                inline=False,
            )
            embed.add_field(
                name="Bot Stats",
                value=f"Servers: `{len(self.client.guilds)}`\nUsers: `{len(self.client.users)}`\nChannels: `{channels}`",
                inline=False,
            )
            if guild.icon:
                embed.set_thumbnail(url=guild.icon.url)
            embed.timestamp = discord.utils.utcnow()
            await idk.send(embed=embed)

        except Exception as e:
            logging.error(f"Error in on_guild_remove: {e}")
