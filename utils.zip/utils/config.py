import os 

TOKEN = os.environ.get("TOKEN")
NAME = "Zyntax"
server = "https://discord.gg/codez"
ch = "https://discord.gg/codez"
OWNER_IDS = [int(x.strip()) for x in os.environ.get("OWNER_IDS", "").split(",") if x.strip()]
BotName = "Zyntax"
serverLink = "https://discord.gg/codez"

invite_link = "https://discord.gg/codez"
website_link = "https://discord.gg/codez"
support_link = "https://discord.gg/codez"
