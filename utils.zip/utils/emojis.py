"""
Zyntax Bot - Emoji Configuration
Developer: void & codez dev
Community: https://discord.gg/codez
"""

# ─────────────────────────────────────────────
#  Replace these IDs with your own server emojis
# ─────────────────────────────────────────────

EMOJIS = {
    # Navigation
    "arrow":             "<:arrow:REPLACE_ID>",
    "arrow_left":        "<:arrow_left:REPLACE_ID>",
    "arrow_right":       "<:arrow_right:REPLACE_ID>",
    "double_left":       "<:double_left:REPLACE_ID>",
    "double_right":      "<:double_right:REPLACE_ID>",

    # Status
    "dot":               "<:dot:REPLACE_ID>",
    "enable":            "<:enable_yes:REPLACE_ID>",
    "disable":           "<:disable_no:REPLACE_ID>",
    "tick":              "<:tick:REPLACE_ID>",
    "cross":             "<:cross:REPLACE_ID>",

    # UI
    "help":              "<:help:REPLACE_ID>",
    "commands":          "<:commands:REPLACE_ID>",
    "categories":        "<:categories:REPLACE_ID>",
    "settings":          "<:settings:REPLACE_ID>",
    "forward":           "<:forward:REPLACE_ID>",

    # Animated
    "loading":           "<a:loading:REPLACE_ID>",
    "butterfly":         "<a:butterfly:REPLACE_ID>",

    # Modules
    "antinuke":          "<:antinuke:REPLACE_ID>",
    "automod":           "<:automod:REPLACE_ID>",
    "moderation":        "<:moderation:REPLACE_ID>",
    "music":             "<:music:REPLACE_ID>",
    "fun":               "<:fun:REPLACE_ID>",
    "utility":           "<:utility:REPLACE_ID>",
    "welcome":           "<:welcome:REPLACE_ID>",
    "ticket":            "<:ticket:REPLACE_ID>",
    "giveaway":          "<:giveaway:REPLACE_ID>",
    "leveling":          "<:leveling:REPLACE_ID>",
    "logging":           "<:logging:REPLACE_ID>",
    "reaction":          "<:reaction:REPLACE_ID>",
    "voice":             "<:voice:REPLACE_ID>",
    "general":           "<:general:REPLACE_ID>",
}

def get(name: str, fallback: str = "•") -> str:
    """Get an emoji by name, falling back to a plain character if not set."""
    val = EMOJIS.get(name, fallback)
    if "REPLACE_ID" in val:
        return fallback
    return val
