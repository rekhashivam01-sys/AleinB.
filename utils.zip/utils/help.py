import discord
from discord.ext import commands
from discord import ui
from utils.Tools import getConfig


class HelpLayout(ui.LayoutView):
    """Main help menu — shows all module categories."""

    def __init__(self, mapping: dict, ctx: commands.Context, prefix: str):
        super().__init__(timeout=300.0)
        self.mapping = mapping
        self.ctx = ctx
        self.prefix = prefix

        self.container = ui.Container(accent_color=None)
        self._build_home()
        self.add_item(self.container)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _cog_line(self, cog) -> str:
        """Return a single display line for a cog category."""
        try:
            _, label, _ = cog.help_custom()
        except Exception:
            label = type(cog).__name__
        return f">> {label}"

    def _total_commands(self) -> int:
        total = 0
        for cog, cmds in self.mapping.items():
            if cog and hasattr(cog, "help_custom"):
                total += len([c for c in cmds if not c.hidden])
        return total

    # ── build page ───────────────────────────────────────────────────────────

    def _build_home(self):
        self.container.clear_items()

        total = self._total_commands()
        bot = self.ctx.bot

        self.container.add_item(ui.TextDisplay(
            f"**Hey, I'm {bot.user.name}**\n\n"
            f"- My prefix for this server is `{self.prefix}`\n"
            f"- Type `{self.prefix}help [command]` for more\n"
            f"- Total commands: **{total}**"
        ))
        self.container.add_item(ui.Separator())

        lines = []
        for cog in self.mapping:
            if cog and hasattr(cog, "help_custom"):
                lines.append(self._cog_line(cog))

        if lines:
            self.container.add_item(ui.TextDisplay("\n".join(lines)))
            self.container.add_item(ui.Separator())

        self.container.add_item(ui.TextDisplay(
            f"-# Use `{self.prefix}help <command>` to see details for a specific command."
        ))

    # ── interaction guard ─────────────────────────────────────────────────────

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(
                "Run this command yourself to interact with it.", ephemeral=True
            )
            return False
        return True


# Alias kept for any existing import
View = HelpLayout
